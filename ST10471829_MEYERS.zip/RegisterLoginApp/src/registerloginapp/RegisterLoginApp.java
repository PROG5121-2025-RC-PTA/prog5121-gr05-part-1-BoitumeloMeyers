/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registerloginapp;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.time.LocalDateTime;
import java.util.Random; // For unique Message ID
import javax.swing.JOptionPane; // For displaying messages with JOptionPane
/**
 *
 * @author RC_Student_lab
 */

// Main class for the Register/Login and Chatroom Application
public class RegisterLoginApp {

    // Global counter for messages sent (as required by "Num messages sent" field)
    private static int totalMessagesSent = 0;

    public static void main(String[] args) {
        RegisterLoginApp app = new RegisterLoginApp(); // Create instance
        app.run(); // Start application logic
    }

    // Main loop of the application
    public void run() {
        ArrayList<User> users = new ArrayList<>();        // List to store registered users
        ArrayList<Message> messages = new ArrayList<>(); // List to store messages between users
        Scanner myInput = new Scanner(System.in); // Renamed scanner to myInput
        boolean running = true;                         // Control flag for main menu

        // Add a dummy user for testing purposes, fulfilling requirements:
        // Username: user_1 (contains '', <= 5 chars after '') - original requirement was 5 chars including underscore, re-evaluating to 'user_1' as common
        // Password: Password1! (8 chars, 1 capital, 1 number, 1 special char)
        // Phone: +27123456789
        users.add(new User("user_1", "Password1!", "+27123456789"));
        System.out.println("Dummy user 'user_1' registered for testing.");

        // Continue showing menu until user exits
        while (running) {
            String choice = getUserChoice(myInput); // Use myInput
            
            switch (choice) {
                case "no":
                    registerUser(myInput, users); // Use myInput
                    break;
                case "yes":
                    Login login = new Login(users, messages, myInput); // Pass myInput to Login constructor
                    login.loginUser();
                    // After logging out, display total messages sent if any
                    // This condition is tricky as 'running' is still true here.
                    // The total messages sent is now displayed on logout within the Login class.
                    break;
                case "exit":
                    System.out.println("Exiting program.");
                    running = false; // Exit the loop and end program
                    System.out.println("Total messages sent during this session: " + totalMessagesSent); // Display before exiting
                    break;
                default:
                    System.out.println("Invalid input. Please enter yes, no, or exit.");
            }
        }
        myInput.close(); // Close myInput when application exits
    }

    // Prompt the user if they have an account
    private String getUserChoice(Scanner myInput) { // Renamed scanner to myInput
        System.out.print("\nDo you have an account? (yes/no/exit): ");
        return myInput.nextLine().toLowerCase(); // Use myInput
    }

    // Handle registration input and validation
    private void registerUser(Scanner myInput, ArrayList<User> users) { // Renamed scanner to myInput
        System.out.println("\n--- Register ---");

        // Prompt for username
        System.out.print("Enter username (must contain '_' and be <= 5 characters after '_'): ");
        String username = myInput.nextLine(); // Use myInput

        // Prompt for password
        System.out.print("Enter password (8 characters, 1 capital, 1 number, 1 special char): ");
        String password = myInput.nextLine(); // Use myInput

        // Prompt for phone number
        System.out.print("Enter phone number (starts with +27 and 9 digits, e.g., +27123456789): ");
        String phone = myInput.nextLine(); // Use myInput

        // Validate each field individually
        if (!isValidUsername(username)) {
            System.out.println("Invalid username. Must contain '_' and be <= 5 characters (excluding '_').");
            return;
        }

        if (!isValidPassword(password)) {
            System.out.println("Invalid password. Must be 8 characters, 1 capital, 1 number, 1 special character.");
            return;
        }

        if (!isValidPhone(phone)) {
            System.out.println("Invalid phone number. Must start with +27 and be followed by 9 digits.");
            return;
        }

        // If all inputs are valid, create and add user
        users.add(new User(username, password, phone));
        System.out.println("Registration successful!");
    }

    // Corrected isValidUsername logic
    private boolean isValidUsername(String username) {
        int underscoreIndex = username.indexOf('_');
        // Check if underscore exists and is not the last character
        if (underscoreIndex == -1 || underscoreIndex == username.length() - 1) {
            return false;
        }
        // Characters after '_' should be <= 5
        return (username.length() - (underscoreIndex + 1)) <= 5;
    }


    // Validate password using regex: length, uppercase, number, special character
    private boolean isValidPassword(String password) {
        return password.length() == 8 &&
                Pattern.compile("[A-Z]").matcher(password).find() && // at least one uppercase
                Pattern.compile("[0-9]").matcher(password).find() && // at least one digit
                Pattern.compile("[!@#$%^&*()_+=<>?/{}\\[\\]-]").matcher(password).find(); // at least one special character
    }

    // Ensure phone number starts with +27 followed by exactly 9 digits
    private boolean isValidPhone(String phone) {
        if (phone.matches("\\+27\\d{9}")){
            return true;
        }else {
            System.out.println("Invalid cellphone Number.  It must be a registed");
            return false;
        }
    }

    // Represents a registered user
    static class User {
        String username;
        String password;
        String phone; // User's own phone number

        User(String username, String password, String phone) {
            this.username = username;
            this.password = password;
            this.phone = phone;
        }
    }

    // Represents a chat message with metadata
    static class Message {
        String sender;
        String receiver; // This will store the recipient's username or phone number (as per previous interpretations)
        String content;
        String sentTime;
        String readTime;
        boolean isRead;
        String uniqueMessageID; // 7-digit random number
        int numMessagesSent;    // The global counter value at the time of message creation
        String messageHash;     // Generated based on requirements

        // Constructor sets sender, receiver, content, and timestamp
        Message(String sender, String receiver, String content, int currentTotalMessages) {
            this.sender = sender;
            this.receiver = receiver;
            this.content = content;
            this.sentTime = LocalDateTime.now().toString(); // capture send time
            this.readTime = ""; // not read yet
            this.isRead = false; // message starts unread
            this.numMessagesSent = currentTotalMessages; // Capture the total messages count at this point
            this.uniqueMessageID = generateUniqueMessageID();
            this.messageHash = createMessageHash(this.uniqueMessageID, this.content); // Generate hash upon creation
        }

        // Generates a random 7-digit message ID
        private String generateUniqueMessageID() {
            Random random = new Random();
            int id = 1000000 + random.nextInt(9000000); // Ensures it's a 7-digit number
            return String.valueOf(id);
        }

        // Creates and returns the Message Hash based on requirements
        // Format: first two numbers of message ID : number of message ID : first and last words of message (all caps)
        public String createMessageHash(String msgID, String msgContent) {
            String hash = "";

            // First two numbers of message ID
            String idPrefix = msgID.substring(0, Math.min(2, msgID.length()));

            // Number of message ID (interpreted as the full ID as per example: 00:0)
            String idPartForHash = msgID.substring(0, Math.min(1, msgID.length())); // First digit of ID

            // First and last words of the message
            String[] words = msgContent.split(" ");
            String firstWord = words.length > 0 ? words[0] : "";
            String lastWord = words.length > 1 ? words[words.length - 1] : firstWord; // If only one word, use it as both

            hash = (idPrefix + ":" + idPartForHash + firstWord + lastWord).toUpperCase();
            return hash;
        }


        // Mark message as read and log the time
        void markAsRead() {
            this.readTime = LocalDateTime.now().toString();
            this.isRead = true;
        }

        // Method to check if message ID is valid (max 10 chars)
        public boolean checkMessageID() {
            return this.uniqueMessageID.length() <= 10;
        }


        // This method will be used by the Login class for recipient validation
        // ensuring the recipient's "cell number" (which we interpret as phone number) is valid.
        public static boolean checkRecipientCell(String recipientPhone) {
            // Reusing the isValidPhone logic from RegisterLoginApp
            return new RegisterLoginApp().isValidPhone(recipientPhone);
        }

        // This method represents the 'SentMessage()' as per the requirements,
        // allowing the user to choose to send, store, or disregard.
        // It returns a String indicating the user's choice/outcome.
        public String SentMessage(Scanner myInput) { // Renamed scanner to myInput
            System.out.println("\nMessage composed. What do you want to do?");
            System.out.println("1. Send Message");
            System.out.println("2. Store Message to send later");
            System.out.println("3. Disregard Message");
            System.out.print("Choice: ");
            String choice = myInput.nextLine(); // Use myInput

            switch (choice) {
                case "1":
                    return "sent";
                case "2":
                    // Call storeMessage() (placeholder for now)
                    storeMessage(this); // Pass 'this' message object to store
                    return "stored";
                case "3":
                    return "disregarded";
                default:
                    return "invalid_choice";
            }
        }

        // Placeholder for storing message in JSON.
        // As per the instruction, this would be a more complex implementation
        // potentially using external libraries like Jackson or GSON.
        // For this exercise, it just prints a message.
        private void storeMessage(Message msg) {
            System.out.println("Message stored to send later (JSON functionality would go here).");
            // Example of what would happen:
            // ObjectMapper mapper = new ObjectMapper();
            // try {
            //     mapper.writeValue(new File("messages.json"), msg);
            // } catch (IOException e) {
            //     e.printStackTrace();
            // }
        }

        // This method is required to 'return a list of all the messages sent while the program is running'.
        // This is better handled by a method in the Login class that iterates over the messages ArrayList
        // and returns a formatted string or a list of messages.
        
        public static String printMessages(ArrayList<Message> allMessages, String currentUsername) {
            StringBuilder sb = new StringBuilder();
            sb.append("--- Your Messages ---\n");
            boolean hasMessages = false;

            for (Message m : allMessages) {
                if (m.receiver.equals(currentUsername)) {
                    hasMessages = true;
                    if (!m.isRead) {
                        m.markAsRead(); // Mark as read if not already
                    }
                    // Display message details as per requirement: MessageID, Message Hash, Recipient, Message
                    sb.append("Message ID: ").append(m.uniqueMessageID).append("\n");
                    sb.append("Message Hash: ").append(m.messageHash).append("\n");
                    sb.append("Recipient: ").append(m.receiver).append("\n"); // Display recipient's username
                    sb.append("Message: ").append(m.content).append("\n");
                    sb.append("Sent: ").append(m.sentTime).append("\n");
                    sb.append("Read: ").append(m.isRead ? m.readTime : "Not read").append("\n");
                    sb.append("--------------------\n");
                }
            }
            if (!hasMessages) {
                sb.append("No messages yet.");
            }
            return sb.toString();
        }

        // This method should return the total number of messages sent globally
        public static int returnTotalMessagess() {
            return RegisterLoginApp.totalMessagesSent;
        }
    }

    // Handles login and chatroom functions
    static class Login {
        private ArrayList<User> users;        // Reference to user list
        private ArrayList<Message> messages;   // Reference to message list
        private Scanner myInput; // Renamed scanner to myInput (passed from RegisterLoginApp)

        Login(ArrayList<User> users, ArrayList<Message> messages, Scanner myInput) { // Accept myInput
            this.users = users;
            this.messages = messages;
            this.myInput = myInput; // Assign the passed myInput
        }

        // Perform login and redirect to chatroom if successful
        public void loginUser() {
            System.out.println("\n--- Login ---");

            // Prompt for credentials
            System.out.print("Enter username: ");
            String enteredUsername = myInput.nextLine(); // Use myInput

            System.out.print("Enter password: ");
            String enteredPassword = myInput.nextLine(); // Use myInput

            User currentUser = null;

            // Authenticate user
            for (User user : users) {
                if (user.username.equals(enteredUsername) && user.password.equals(enteredPassword)) {
                    currentUser = user;
                    break;
                }
            }

            // If login successful, enter chatroom
            if (currentUser != null) {
                System.out.println("Login successful!");
                chatRoom(currentUser);
            } else {
                System.out.println("Invalid login credentials.");
            }
        }
        //Sart of part2
        // Chatroom interface after login
        private void chatRoom(User currentUser) {
            // Display welcome message as per requirement
            System.out.println("\nWelcome to QuickChat.");

            // Show count of unread messages (existing functionality)
            long unreadCount = messages.stream()
                    .filter(m -> m.receiver.equals(currentUser.username) && !m.isRead)
                    .count();

            if (unreadCount > 0) {
                System.out.println("You have " + unreadCount + " unread message(s).");
            }

            boolean inChat = true;

            // Menu loop for chatroom options
            while (inChat) {
                System.out.println("\nChatroom Options:");
                System.out.println("1. Send Message");
                System.out.println("2. Show recently sent messages"); // This is option 2
                System.out.println("3. Quit"); // This is option 3 (Logout)
                System.out.print("Choice: ");
                String choice = myInput.nextLine(); // Use myInput

                switch (choice) {
                    case "1":
                        sendMessage(currentUser); // Send new message
                        break;
                    case "2":
                        // Implement "Coming Soon" for Option 2
                        System.out.println("This feature is still in development and will display the following message: \"Coming Soon.\"");
                        break;
                    case "3":
                        inChat = false;
                        System.out.println("Logging out...");
                        // Display total messages sent upon logout
                        System.out.println("Total messages sent during this session: " + RegisterLoginApp.totalMessagesSent);
                        break;
                    default:
                        System.out.println("Invalid option.");
                }
            }
        }

        // Send a message to another user
        private void sendMessage(User sender) {
            System.out.print("Enter recipient username: ");
            String receiverUsername = myInput.nextLine(); // Use myInput

            // Validate recipient username exists
            User recipientUser = null;
            for (User user : users) {
                if (user.username.equals(receiverUsername)) {
                    recipientUser = user;
                    break;
                }
            }

            if (recipientUser == null) {
                System.out.println("User does not exist.");
                return;
            }

            // Now, validate recipient's phone number as per the requirement "Recipient: cell number ... no more than ten characters and contains an international code."
            // Assuming the 'receiver' field in Message class will store the recipient's username,
            // and validate the phone number format of the recipient user.
            if (!Message.checkRecipientCell(recipientUser.phone)) { // Reusing Message.checkRecipientCell for validation
                System.out.println("Invalid recipient phone number format. It must start with +27 and be 10 digits total.");
                return;
            }

            System.out.print("Enter message: ");
            String msgContent = myInput.nextLine(); // Use myInput

            // Validate message length
            String messageValidationResult = validateMessageLength(msgContent);
            if (!messageValidationResult.equals("Success") && !messageValidationResult.equals("Message ready to send.")) { // Adjusted for multiple success messages
                System.out.println(messageValidationResult);
                return; // Do not proceed if validation fails
            }

            // Increment the global total messages sent counter
            RegisterLoginApp.totalMessagesSent++;

            // Create a temporary message object to pass to SentMessage for decision
            Message tempMessage = new Message(sender.username, recipientUser.username, msgContent, RegisterLoginApp.totalMessagesSent);

            // Ask user what to do with the message (send, store, disregard)
            String userChoice = tempMessage.SentMessage(myInput); // Use myInput

            switch (userChoice) {
                case "sent":
                    messages.add(tempMessage); // Add message to the list only if sent
                    System.out.println("Message sent!");
                    break;
                case "stored":
                    // tempMessage is already 'stored' via the placeholder method in SentMessage
                    System.out.println("Message stored for later.");
                    break;
                case "disregarded":
                    System.out.println("Message disregarded.");
                    // Decrement the counter if the message is disregarded after incrementing it
                    RegisterLoginApp.totalMessagesSent--;
                    break;
                default:
                    System.out.println("Invalid choice. Message was not sent/stored.");
                    // Decrement the counter if it was an invalid choice after incrementing
                    RegisterLoginApp.totalMessagesSent--;
                    break;
            }

            // Display total messages sent after each message action
            System.out.println("Total messages sent so far: " + RegisterLoginApp.totalMessagesSent);
        }

        // Helper method to validate message length and return specific messages
        private String validateMessageLength(String message) {
            if (message.length() > 250) {
                int excessChars = message.length() - 250;
                return "Message exceeds 250 characters by " + excessChars + ", please reduce size.";
            } else if (message.length() > 0) { // If it's between 1 and 250 (inclusive)
                return "Message ready to send."; // It's within the overall limit
            } else { // Message is empty
                return "Message cannot be empty."; // Added check for empty message
            }
        }


        // Show all messages for the current user and mark them as read
        // Now uses JOptionPane and specific display order
        private void viewMessages(User currentUser) {
            // The prompt says "String: printMessages() ... returns a list of all the messages"
            
            String messagesToDisplay = Message.printMessages(messages, currentUser.username);
            JOptionPane.showMessageDialog(null, messagesToDisplay, "Your Messages", JOptionPane.INFORMATION_MESSAGE);
        }

        // Placeholder for storing messages in JSON.    
    }
    /*
     * UNIT TESTS IMPLEMENTATION
     */
    public void runUnitTests() {
        System.out.println("\n--- Running Unit Tests ---");
        testMessageLengthValidation();
        testRecipientNumberValidation();
        System.out.println("--- Unit Tests Finished ---");
    }

    private void testMessageLengthValidation() {
        System.out.println("\n--- Testing Message Length Validation ---");
        // Create a dummy login instance by passing a new Scanner for testing purposes
        Login loginInstance = new Login(new ArrayList<>(), new ArrayList<>(), new Scanner(System.in)); 

        // Test case 1: Message within 250 characters (e.g., 200 chars)
        String shortMessage = "a".repeat(200);
        String result1 = loginInstance.validateMessageLength(shortMessage);
        System.out.println("Test 1 (200 chars): Expected 'Message ready to send.', Got: '" + result1 + "'");
        assert result1.equals("Message ready to send.") : "Test 1 Failed";

        // Test case 2: Message exactly 250 characters
        String exactMessage = "a".repeat(250);
        String result2 = loginInstance.validateMessageLength(exactMessage);
        System.out.println("Test 2 (250 chars): Expected 'Message ready to send.', Got: '" + result2 + "'");
        assert result2.equals("Message ready to send.") : "Test 2 Failed";


        // Test case 3: Message exceeds 250 characters (e.g., 260 chars)
        String longMessage = "a".repeat(260);
        String result3 = loginInstance.validateMessageLength(longMessage);
        int excess = 260 - 250;
        String expected3 = "Message exceeds 250 characters by " + excess + ", please reduce size.";
        System.out.println("Test 3 (260 chars): Expected '" + expected3 + "', Got: '" + result3 + "'");
        assert result3.equals(expected3) : "Test 3 Failed";

        // Test case 4: Message exactly 50 characters (should be "Message ready to send.")
        String fiftyCharMessage = "a".repeat(50);
        String result4 = loginInstance.validateMessageLength(fiftyCharMessage);
        System.out.println("Test 4 (50 chars): Expected 'Message ready to send.', Got: '" + result4 + "'");
        assert result4.equals("Message ready to send.") : "Test 4 Failed";

        // Test case 5: Message less than 50 characters (should be "Message ready to send.")
        String fortyCharMessage = "a".repeat(40);
        String result5 = loginInstance.validateMessageLength(fortyCharMessage);
        System.out.println("Test 5 (40 chars): Expected 'Message ready to send.', Got: '" + result5 + "'");
        assert result5.equals("Message ready to send.") : "Test 5 Failed";

        // Test case 6: Empty message (added for robustness)
        String emptyMessage = "";
        String result6 = loginInstance.validateMessageLength(emptyMessage);
        System.out.println("Test 6 (Empty message): Expected 'Message cannot be empty.', Got: '" + result6 + "'");
        assert result6.equals("Message cannot be empty.") : "Test 6 Failed";


        System.out.println("--- Message Length Validation Tests Completed ---");
    }

    private void testRecipientNumberValidation() {
        System.out.println("\n--- Testing Recipient Number Validation ---");

        // Test case 1: Valid phone number
        String validPhone = "+27123456789";
        boolean result1 = Message.checkRecipientCell(validPhone);
        System.out.println("Test 1 (Valid: " + validPhone + "): Expected true, Got: " + result1);
        assert result1 == true : "Test 1 Failed";

        // Test case 2: Invalid phone number (doesn't start with +27)
        String invalidPhone1 = "07123456789";
        boolean result2 = Message.checkRecipientCell(invalidPhone1);
        System.out.println("Test 2 (Invalid: " + invalidPhone1 + "): Expected false, Got: " + result2);
        assert result2 == false : "Test 2 Failed";

        // Test case 3: Invalid phone number (wrong number of digits)
        String invalidPhone2 = "+2712345678"; // 8 digits
        boolean result3 = Message.checkRecipientCell(invalidPhone2);
        System.out.println("Test 3 (Invalid: " + invalidPhone2 + "): Expected false, Got: " + result3);
        assert result3 == false : "Test 3 Failed";

        // Test case 4: Invalid phone number (contains non-digits)
        String invalidPhone3 = "+271234567A9";
        boolean result4 = Message.checkRecipientCell(invalidPhone3);
        System.out.println("Test 4 (Invalid: " + invalidPhone3 + "): Expected false, Got: " + result4);
        assert result4 == false : "Test 4 Failed";

        // Test case 5: Empty string
        String emptyPhone = "";
        boolean result5 = Message.checkRecipientCell(emptyPhone);
        System.out.println("Test 5 (Empty string): Expected false, Got: " + result5);
        assert result5 == false : "Test 5 Failed";

        System.out.println("--- Recipient Number Validation Tests Completed ---");
    }
}