/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registerloginapp;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


public class RegisterLoginApp {

    // Tracks how many messages the user has created
    private int messageCount = 0;

    // A single list to store all messages (sent, stored, or disregarded)
    private final ArrayList<Message> allMessages = new ArrayList<>();

    // Used for generating random message IDs
    private final Random random = new Random();

    public static void main(String[] args) {
        System.out.print("Hi :) Welcome to Supreme ChatRoom, were you get to interact with yours friends and family.");
        RegisterLoginApp app = new RegisterLoginApp();
        app.run(); // Start the application
    }

    // Main application loop
    public void run() {
        ArrayList<User> users = new ArrayList<>(); // Stores registered users
        Scanner myInput = new Scanner(System.in);
        boolean running = true;

        while (running) {
            String choice = getUserChoice(myInput); // Ask user for account status

            switch (choice) {
                case "no":
                    registerUser(myInput, users); // Register new user
                    Login loginAfterReg = new Login(users, myInput);
                    if (loginAfterReg.loginUser()) {
                        System.out.println("Welcome to Quickshare\n");
                        runMessageFeature(myInput); // Launch messaging feature
                    }
                    break;
                case "yes":
                    Login login = new Login(users, myInput);
                    if (login.loginUser()) {
                        System.out.println("Welcome to Quickshare\n");
                        runMessageFeature(myInput);
                    }
                    break;
                case "exit":
                    System.out.println("Exiting program.\n");
                    running = false; // Exit loop
                    break;
                default:
                    System.out.println("Invalid input. Please enter yes, no, or exit.\n");
            }
        }
    }

    // Prompt user for account status
    private String getUserChoice(Scanner myInput) {
        System.out.print("\nDo you have an account? (yes/no/exit): ");
        return myInput.nextLine().toLowerCase();
    }

    // Handles user registration with input validation
    private void registerUser(Scanner myInput, ArrayList<User> users) {
        System.out.println("\n--- Register ---");

        System.out.print("Enter username (must contain an underscore and be 5 characters max): ");
        String username = myInput.nextLine();

        System.out.print("Enter password (8 characters, 1 capital, 1 number, 1 special character): ");
        String password = myInput.nextLine();

        System.out.print("Enter phone number (starts with +27 and 9 digits): ");
        String phone = myInput.nextLine();

        // Validate inputs
        if (!isValidUsername(username)) {
            System.out.println("Invalid username.\n");
            return;
        }

        if (!isValidPassword(password)) {
            System.out.println("Invalid password.\n");
            return;
        }

        if (!isValidPhone(phone)) {
            System.out.println("Invalid phone number.\n");
            return;
        }

        // Add user if all inputs are valid
        users.add(new User(username, password, phone));
        System.out.println("Registration successful!\n");
    }

    // Check if username is valid
    private boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check if password meets complexity requirements
    private boolean isValidPassword(String password) {
        return password.length() == 8 &&
                Pattern.compile("[A-Z]").matcher(password).find() &&
                Pattern.compile("[0-9]").matcher(password).find() &&
                Pattern.compile("[!@#$%^&*()_+=<>?/{}\\[\\]-]").matcher(password).find();
    }

    // Check if phone number starts with +27 and has 9 digits
    private boolean isValidPhone(String phone) {
        return phone.matches("\\+27\\d{9}");
    }

    // Messaging functionality after successful login
    private void runMessageFeature(Scanner myInput) {
        boolean messaging = true;
        while (messaging) {
            System.out.println("Select an option:");
            System.out.println("1. Compose Message");
            System.out.println("2. Display the longest sent message");
            System.out.println("3. Search for a message by ID");
            System.out.println("4. Search for messages by recipient");
            System.out.println("5. Delete a message using its hash");
            System.out.println("6. Display a full report of all sent messages");
            System.out.println("7. Quit to main menu");
            System.out.println();

            String option = myInput.nextLine();

            switch (option) {
                case "1":
                    composeMessage(myInput);
                    break;
                case "2":
                    displayLongestSentMessage();
                    break;
                case "3":
                    searchByMessageID(myInput);
                    break;
                case "4":
                    searchByRecipient(myInput);
                    break;
                case "5":
                    deleteByHash(myInput);
                    break;
                case "6":
                    displayReport();
                    break;
                case "7":
                    messaging = false;
                    System.out.println("Returning to main menu.\n");
                    break;
                default:
                    System.out.println("Invalid option.\n");
            }
        }
    }

    // Composes a message, validates input, and processes sending/storage
    private void composeMessage(Scanner myInput) {
        System.out.print("Enter recipient phone number (international format, must start with '+' and has to have 15 characters max (including '+')): ");
        String recipient = myInput.nextLine();

        if (!recipient.startsWith("+") || recipient.length() > 15) {
            System.out.println("Invalid recipient number format.\n");
            return;
        }

        System.out.print("Enter message (max 250 characters): ");
        String messageContent = myInput.nextLine();

        if (messageContent.length() > 250) {
            System.out.println("Please enter a message of less than 250 characters.\n");
            return;
        }

        messageCount++;
        long messageID = 100000000000000L + random.nextInt(900000000);
        String[] words = messageContent.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        String hash = (String.valueOf(messageID).substring(0, 2) + ":" + messageCount + ":" + firstWord + ":" + lastWord).toUpperCase();

        System.out.println("\nChoose next step:");
        System.out.println("1. Send message");
        System.out.println("2. Disregard message");
        System.out.println("3. Store message to send later");
        String action = myInput.nextLine();

        Message message = new Message(messageID, hash, recipient, messageContent);

        switch (action) {
            case "1":
                message.setStatus(Status.SENT);
                allMessages.add(message);
                System.out.println("\nYour message has been sent:");
                System.out.println("Message ID: " + messageID);
                System.out.println("Message Hash: " + hash);
                System.out.println("Recipient: " + recipient);
                System.out.println("Message: " + messageContent + "\n");
                break;
            case "2":
                message.setStatus(Status.DISREGARDED);
                allMessages.add(message);
                System.out.println("Message disregarded.\n");
                break;
            case "3":
                message.setStatus(Status.STORED);
                allMessages.add(message);
                System.out.println("Message stored.\n");
                break;
            default:
                messageCount--; // Decrement as no message was actioned
                System.out.println("Invalid action. Message not created.\n");
        }
    }

    // f. Display a report that lists the full details of all the sent messages.
    private void displayReport() {
        ArrayList<Message> sentMessages = allMessages.stream()
                .filter(m -> m.getStatus() == Status.SENT)
                .collect(Collectors.toCollection(ArrayList::new));

        if (sentMessages.isEmpty()) {
            System.out.println("No messages have been sent.\n");
            return;
        }

        System.out.println("--- Sent Messages Report ---");
        for (Message msg : sentMessages) {
            System.out.println("Message Hash: " + msg.getMessageHash());
            System.out.println("Recipient: " + msg.getRecipient());
            System.out.println("Message: " + msg.getContent());
            System.out.println("----------------------------");
        }
        System.out.println();
    }
    
    // b. Display the longest sent message.
    private void displayLongestSentMessage() {
        allMessages.stream()
                .filter(m -> m.getStatus() == Status.SENT)
                .max(Comparator.comparingInt(m -> m.getContent().length()))
                .ifPresentOrElse(
                        longestMsg -> {
                            System.out.println("Longest sent message is:");
                            System.out.println("\"" + longestMsg.getContent() + "\"\n");
                        },
                        () -> System.out.println("There are no sent messages to compare.\n")
                );
    }

    // c. Search for a message ID and display the corresponding recipient and message.
    private void searchByMessageID(Scanner myInput) {
        System.out.print("Enter the Message ID to search for: ");
        try {
            long idToFind = Long.parseLong(myInput.nextLine());
            allMessages.stream()
                    .filter(m -> m.getMessageID() == idToFind)
                    .findFirst()
                    .ifPresentOrElse(
                            msg -> {
                                System.out.println("Message found:");
                                System.out.println("Recipient: " + msg.getRecipient());
                                System.out.println("Message: " + msg.getContent() + "\n");
                            },
                            () -> System.out.println("No message found with that ID.\n")
                    );
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID format. Please enter a number.\n");
        }
    }

    // d. Search for all the messages sent to a particular recipient.
    private void searchByRecipient(Scanner myInput) {
        System.out.print("Enter the recipient's phone number to search for: ");
        String recipientToFind = myInput.nextLine();

        ArrayList<Message> recipientMessages = allMessages.stream()
                .filter(m -> (m.getStatus() == Status.SENT || m.getStatus() == Status.STORED) && m.getRecipient().equalsIgnoreCase(recipientToFind))
                .collect(Collectors.toCollection(ArrayList::new));

        if (recipientMessages.isEmpty()) {
            System.out.println("No sent or stored messages found for this recipient.\n");
        } else {
            System.out.println("Messages for " + recipientToFind + ":");
            for (Message msg : recipientMessages) {
                System.out.println("- \"" + msg.getContent() + "\" (" + msg.getStatus() + ")");
            }
            System.out.println();
        }
    }

    // e. Delete a message using the message hash.
    private void deleteByHash(Scanner myInput) {
        System.out.print("Enter the Message Hash to delete: ");
        String hashToDelete = myInput.nextLine().toUpperCase();

        boolean removed = allMessages.removeIf(m -> {
            if (m.getMessageHash().equals(hashToDelete)) {
                System.out.println("Message \"" + m.getContent() + "\" successfully deleted.\n");
                return true;
            }
            return false;
        });

        if (!removed) {
            System.out.println("No message found with that hash.\n");
        }
    }

    // User class for holding account data
    static class User {
        String username, password, phone;

        User(String username, String password, String phone) {
            this.username = username;
            this.password = password;
            this.phone = phone;
        }
    }

    // Handles login operations
    static class Login {
        private final ArrayList<User> users;
        private final Scanner myInput;

        Login(ArrayList<User> users, Scanner myInput) {
            this.users = users;
            this.myInput = myInput;
        }

        public boolean loginUser() {
            System.out.println("\n--- Login ---");
            System.out.print("Enter username: ");
            String enteredUsername = myInput.nextLine();
            System.out.print("Enter password: ");
            String enteredPassword = myInput.nextLine();

            for (User user : users) {
                if (user.username.equals(enteredUsername) && user.password.equals(enteredPassword)) {
                    System.out.println("Login successful!\n");
                    return true;
                }
            }
            System.out.println("Invalid login credentials.\n");
            return false;
        }
    }
    
    // Enum to represent the status of a message
    enum Status {
        SENT,
        STORED,
        DISREGARDED
    }

    // Class to hold all data for a single message
    static class Message {
        private final long messageID;
        private final String messageHash;
        private final String recipient;
        private final String content;
        private Status status;

        public Message(long messageID, String messageHash, String recipient, String content) {
            this.messageID = messageID;
            this.messageHash = messageHash;
            this.recipient = recipient;
            this.content = content;
        }

        // Getters
        public long getMessageID() { return messageID; }
        public String getMessageHash() { return messageHash; }
        public String getRecipient() { return recipient; }
        public String getContent() { return content; }
        public Status getStatus() { return status; }

        // Setter
        public void setStatus(Status status) { this.status = status; }
    }
}